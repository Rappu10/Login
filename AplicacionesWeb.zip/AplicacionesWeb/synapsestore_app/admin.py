from django.contrib import admin
from .models import Producto, Usuario

admin.site.register(Producto)
admin.site.register(Usuario)