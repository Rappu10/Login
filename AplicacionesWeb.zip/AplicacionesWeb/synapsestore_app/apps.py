from django.apps import AppConfig


class SynapsestoreAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'synapsestore_app'

